from langgraph.graph import StateGraph
from langchain.chat_models import ChatOpenAI
from app.tools import web_search_tool, summarizer_tool
from langchain.agents import tool
from pydantic import BaseModel
from langchain_core.messages import HumanMessage
import os
from dotenv import load_dotenv
load_dotenv()

@tool
def question_decomposer(query: str) -> list:
    """Decompose the query."""
    print("query : ", query)
    return f"Refined sub-question for: {query}"
    # return [f"Sub-question 1 for : {query}", f"Sub-question 2 for: {query}"]

def build_agent_graph(mode):
    OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
    OPENAI_DEPLOYMENT = os.getenv("OPENAI_DEPLOYMENT")
    llm = ChatOpenAI(openai_api_key=OPENAI_API_KEY,model=OPENAI_DEPLOYMENT, temperature="0.3")
    graph = StateGraph(dict)

    graph.add_node("decompose", question_decomposer)
    graph.add_node("search", web_search_tool)
    graph.add_node("summarize", summarizer_tool)

    graph.add_node("synthesize", lambda input: llm.invoke([HumanMessage(content=input)]))
    graph.set_entry_point("decompose")
    graph.add_edge("decompose", "search")
    graph.add_edge("search", "summarize")
    graph.add_edge("summarize", "synthesize")
    graph.set_finish_point("synthesize")

    return graph.compile()
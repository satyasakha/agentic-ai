from app.graph import build_agent_graph
import json
import os
from datetime import datetime

def save_report(query, mode, report, sources):
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"data/report_{timestamp}.json"
    os.makedirs("data", exist_ok=True)
    with open(filename, "w") as f:
        json.dump({"query":query, "mode":mode, "report":report, "sources":sources}, f, indent=2)

def run_research_agent(query:str, mode:str):
    graph = build_agent_graph(mode)
    # result = graph.invoke(query)
    result = graph.invoke({"query":query})
    print("result : ", result)
    if hasattr(result, "content"):
        report = result.content
    else:
        report = str(result)
    sources = []
    save_report(query, mode, report, sources)
    return report, sources
from langchain.agents import tool
from langchain.chat_models import ChatOpenAI

@tool
def summarizer_tool(results:str, model) -> str:
    """Summarize the web content"""
    llm = ChatOpenAI(model=model, temperature=0.5)
    response = llm.invoke(f"Summarize the web result : {results}")
    return response.content
from langchain.agents import tool
import requests
import os

@tool
def web_search_tool(query: str) -> str:
    """Search the web and return a summary."""
    api_key = os.getenv("GOOGLE_API_KEY")
    cse_id = os.getenv("GOOGLE_CSE_ID")
    url = os.getenv("SEARCH_URL")
    params = {
        "key":api_key,
        "cx":cse_id,
        "q":query,
        "num":5
    }
    response = requests.get(url, params=params)
    try:
        results = response.json()
        snippets = [item["snippet"] for item in results.get("items", [])]
        return "\n\n".join(snippets)
    except Exception as e:
        return f"[ERROR] Failed to parse search results: {e}\nRaw Response: {response.text}"
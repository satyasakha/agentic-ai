def test_report_format():
    from app.agent import run_research_agent
    report, sources = run_research_agent("Top AI startups in 2025", "Quick")
    assert isinstance(report, str) and len(report) > 10
    assert isinstance(sources, list)
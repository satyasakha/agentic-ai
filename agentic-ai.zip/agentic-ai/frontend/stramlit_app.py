import streamlit as st
from app.agent import run_research_agent
import json
import os
from wordcloud import WordCloud
import matplotlib.pyplot as plt

st.title("Autonomous Research Analyst")
query = st.text_input("Enter your research qeustion:")
mode = st.selectbox("Select research mode", ["Quick", "In-depth", "Weekly Tracker"])

if st.button("Start Research") and query:
    with st.spinner("Agent as work..."):
        report, sources = run_research_agent(query, mode)
        print("report : ", report)
        print("sources", sources)
        st.success("Done!")
        st.markdown(report, unsafe_allow_html=True)
        for src in sources:
            st.write(f"[Source]({src})")
        st.download_button("Download Report", report.encode(), "research_report.md")

        wc = WordCloud(width=800, height=400, background_color='white').generate(report)
        st.subheader("word cloud of findings")
        fig, ax = plt.subplots()
        ax.imshow(wc, interpolation='bilinear')
        ax.axis("off")
        st.pyplot(fig)

st.subheader("Past Reports")
if os.path.exists("data"):
    for filename in sorted(os.listdir("data"), reverse=True):
        if filename.endswith(".json"):
            with open(f"data/{filename}", "r") as f:
                session = json.load(f)
                with st.expander(f"{filename} -{session['query']}"):
                    st.markdown(session["report"], unsafe_allow_html=True)
                    for src in session.get("sources", []):
                        st.write(f"[Source]({src})")